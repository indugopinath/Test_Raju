/**
 * 
 */
package com.IBM.main;

import java.util.Scanner;

import com.IBM.utils.CSVUtils;

/**
 * @author GangaRaju U
 *
 */
public class CSVFileSortMain {

	/**
	 * @param1 .CSV file1 name 
	 * @param2 file1 column name to sort
	 * @param3 .CSV file2 name
	 * @param4 file2 column name for file1 rows sorting
	 * @return prints .CSV sorted in this special way  
	 */
	public static void main(String[] args) {
		Scanner s = null;
    	Scanner s1 = null;
    	Scanner s2= null;
    	Scanner s3 = null;
		try {
			s = new Scanner(System.in);
	    	System.out.println("Please enter File1 address: (Eg: D:\\file1.csv)");
	        String csvFile1 = s.next();
	        
	        s1 = new Scanner(System.in);
	        System.out.println("Please enter File1 Sorting Column (Eg: b):");
	        String csvFile1Column = s1.next();
	        
	        s2 = new Scanner(System.in);
	        System.out.println("Please enter File2 address (Eg: D:\\file2.csv):");
	        String csvFile2 = s2.next();
	        
	        s3 = new Scanner(System.in);
	        System.out.println("Please enter File2 Filter Column (Eg: d):");
	        String csvFile2Column = s3.next();
	        

			CSVUtils utils = new CSVUtils();
			utils.processCSVData(csvFile1, csvFile1Column, csvFile2, csvFile2Column);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(s != null)
				s.close();
			if(s != null)
				s1.close();
			if(s != null)
				s2.close();
			if(s != null)
				s3.close();
		}

	}

}

