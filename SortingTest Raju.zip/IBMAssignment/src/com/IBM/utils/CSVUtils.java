package com.IBM.utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CSVUtils {

	// Default variables
    private static final char DEFAULT_SEPARATOR = ',';
    private static final char DEFAULT_QUOTE = '"';
    private static int  DEFAULT_FILTER_COLUMN = 0;
    private static int  DEFAULT_SORTED_COLUMN = 0;
    
    public CSVUtils() {
		System.out.println("OUTPUT");
        System.out.println("--------------------");
	}

    public void processCSVData(String csvFile1, String csvFile1Column, String csvFile2, String csvFile2Column) throws Exception {
    	Scanner scanner = null;
    	Scanner scanner1 = null;
    	Scanner scanner2 = null;
    	try{       
    		//Flags to bypass
	        boolean filterColumnFound = false, skipHeader = true, sortedColumnFound = false, headerSkipFlag = false;
	        //To skip if sorting done in csvFile1
	        int sortingCount = 0;
	        //Calculating total number of lines in csvFile1 to sort
	        int csvFile1LineNumCount = countLines(csvFile1);
	        
	        List<String> csvSortedLines = new ArrayList<String>();
	        List<String> csvFile1LineData = new ArrayList<String>();

	        //This scanner is to capture csvFile1 complete data
	        scanner = new Scanner(new File(csvFile1));
	        while (scanner.hasNext()){
	        	List<String> csvFileLine = parseLine(scanner.nextLine());
	        	for(int i = 0; i < csvFileLine.size() && !sortedColumnFound; i++){
	        		//Finding sorting column number
	        		if(csvFile1Column.equalsIgnoreCase(csvFileLine.get(i).trim())){
	        			DEFAULT_SORTED_COLUMN = i;
	        			sortedColumnFound = true;
	        			break;
	        		}
	            }
	        	if(!sortedColumnFound)
	        	{
	    			System.out.println("Sort Order Definition Column not found in File1!!!");
	    			return;
	    		}
	        	csvFile1LineData.add(csvFileLine.toString().trim());
	        }
	        
	        //Outer scanner (csvFile2) to sort csvFile1 data 
	        scanner2 = new Scanner(new File(csvFile2));
	        while (scanner2.hasNext()){
	        	List<String> csvFile2Line = parseLine(scanner2.nextLine());
	        	
	        	//To find the filter column number
	        	for(int i = 0; i < csvFile2Line.size() && !filterColumnFound; i++){
	        		if(csvFile2Column.equalsIgnoreCase(csvFile2Line.get(i).trim())){
	        			DEFAULT_FILTER_COLUMN = i;
	        			filterColumnFound = true;
	        			break;
	        		}
	            }
	        	if(!sortedColumnFound)
	        	{
	    			System.out.println("Sort Order Definition Column not found in File2!!!");
	    			return;
	    		}
	        	//Following is to skip header data scanning
	        	if(skipHeader){
	        		skipHeader = false;
	        		continue;
	        	}
	        	
	        	//System.out.println("FILTER COLUMN [VALUE = " + csvFile2Line.get(DEFAULT_FILTER_COLUMN)+ "]");
	
	        	//this variable is to skip header validation
	        	int rowCnt = 0;
	        	
	        	//Condition to exit, if csvFile sorting completed [if reached EOF (End of File)].
	        	if(csvFile1LineNumCount - 1 == sortingCount)
	        		break;
	        	
	        	//Inner scanner (csvFile1 scanner) to sort data using filer (csvFile2) data 
	            scanner1 = new Scanner(new File(csvFile1));
		        while (scanner1.hasNext()) {
		        	boolean matchFound = false;
		        	//Adding csvFile1 header data in sorting List
		        	List<String> csvFile1Line = parseLine(scanner1.nextLine());
		        	if(rowCnt == 0 && !headerSkipFlag){
		        		if(!csvSortedLines.contains(csvFile1Line.toString().trim()))
		        			csvSortedLines.add(csvFile1Line.toString().trim());
			            //System.out.println(csvFile1Line.get(0) + ", " + csvFile1Line.get(1) + " , " + csvFile1Line.get(2));
		        		rowCnt++;
		        		headerSkipFlag = true;
		        		continue;
		        	}
		            
		        	//Condition to extract Match found data
	            	if(csvFile1Line.get(DEFAULT_SORTED_COLUMN).trim().equalsIgnoreCase(csvFile2Line.get(DEFAULT_FILTER_COLUMN).trim())){
		            		//System.out.println("Match Found"+rowCnt);
		            		csvSortedLines.add(csvFile1Line.toString().trim());
		            		//System.out.println(csvFile1Line.get(0) + ", " + csvFile1Line.get(1) + " , " + csvFile1Line.get(2));
		            		matchFound = true;
		            		break;
		            	}
	        
	            	//If match found exit from inner loop
	            	if (matchFound){
		            	sortingCount++;
		            	break;
		            }
		            
		            //System.out.println(csvFile1Line.get(0) + ", " + csvFile1Line.get(1) + " , " + csvFile1Line.get(2));
		            rowCnt++;
		        }
		        scanner1.close();
	        }
	        scanner2.close();
	        
	        //removing sorted list data from full csvFile1 data list
	        csvFile1LineData.removeAll(csvSortedLines);
	        
	        //Tailing unmatched data to the sorted list 
	        csvSortedLines.addAll(csvFile1LineData);
	        
	        //Printing the output
	        for(String csvFile1SortedData : csvSortedLines){
	        	System.out.println(csvFile1SortedData.trim());
	        }
    	}catch(Exception e){
    		e.printStackTrace();
    	}finally{
    		if(scanner != null)
    			scanner.close();
    		if(scanner1 != null)
    			scanner1.close();
    		if(scanner2 != null)
    			scanner2.close();
    	}
    }
    
    public static int countLines(String filename) throws IOException {
        InputStream is = new BufferedInputStream(new FileInputStream(filename));
        try {
            byte[] c = new byte[1024];
            int count = 0;
            int readChars = 0;
            boolean empty = true;
            while ((readChars = is.read(c)) != -1) {
                empty = false;
                for (int i = 0; i < readChars; ++i) {
                    if (c[i] == '\n') {
                        ++count;
                    }
                }
            }
            return (count == 0 && !empty) ? 1 : count;
        } finally {
            is.close();
        }
    }

    public static List<String> parseLine(String cvsLine) {
        return parseLine(cvsLine, DEFAULT_SEPARATOR, DEFAULT_QUOTE);
    }

    public static List<String> parseLine(String cvsLine, char separators) {
        return parseLine(cvsLine, separators, DEFAULT_QUOTE);
    }

    public static List<String> parseLine(String cvsLine, char separators, char customQuote) {

        List<String> result = new ArrayList<>();

        //if empty, return!
        if (cvsLine == null || cvsLine.isEmpty()) {
            return result;
        }

        if (customQuote == ' ') {
            customQuote = DEFAULT_QUOTE;
        }

        if (separators == ' ') {
            separators = DEFAULT_SEPARATOR;
        }

        StringBuffer curVal = new StringBuffer();
        boolean inQuotes = false;
        boolean startCollectChar = false;
        boolean doubleQuotesInColumn = false;

        char[] chars = cvsLine.toCharArray();

        for (char ch : chars) {

            if (inQuotes) {
                startCollectChar = true;
                if (ch == customQuote) {
                    inQuotes = false;
                    doubleQuotesInColumn = false;
                } else {

                    //Fixed : allow "" in custom quote enclosed
                    if (ch == '\"') {
                        if (!doubleQuotesInColumn) {
                            curVal.append(ch);
                            doubleQuotesInColumn = true;
                        }
                    } else {
                        curVal.append(ch);
                    }

                }
            } else {
                if (ch == customQuote) {

                    inQuotes = true;

                    //Fixed : allow "" in empty quote enclosed
                    if (chars[0] != '"' && customQuote == '\"') {
                        curVal.append('"');
                    }

                    //double quotes in column will hit this!
                    if (startCollectChar) {
                        curVal.append('"');
                    }

                } else if (ch == separators) {

                    result.add(curVal.toString());

                    curVal = new StringBuffer();
                    startCollectChar = false;

                } else if (ch == '\r') {
                    //ignore LF characters
                    continue;
                } else if (ch == '\n') {
                    //the end, break!
                    break;
                } else {
                    curVal.append(ch);
                }
            }

        }

        result.add(curVal.toString());

        return result;
    }

}
